/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

/**
 *
 * @author leand
 */
public interface AppConfig {
    
    static String PATH = "src/data/";
    static String ARCHIVO_BINARIO = PATH + "registros.bin";
    static String ARCHIVO_CSV = PATH + "registros.csv";
    static String ARCHIVO_TXT = PATH + "reporte.txt";
    static String TITULO_REPORTE = "REPORTE DE REGISTROS ALIENIGENAS";
}
