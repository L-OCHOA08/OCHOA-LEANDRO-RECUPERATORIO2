/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app;

import config.AppConfig;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import model.ClasificacionMuestra;
import model.ExpedienteCampo;
import model.ExpedienteLaboratorio;
import model.RegistroAlienigena;
import model.TipoEvento;
import model.Ubicacion;
import service.ArchivoAlienigena;
import service.ServicioRegistros;

/**
 *
 * @author Ochoa Leandro
 */
public class Principal {

    public static void main(String[] args) {
        try {
            ArchivoAlienigena<RegistroAlienigena> archivo = new ArchivoAlienigena<>();
            archivo.agregar(new ExpedienteCampo(1, "Luces sobre la Patagonia", "Dra.Vega", new Ubicacion("Argentina", "Patagonia"), 4, TipoEvento.AVISTAMIENTO));
            archivo.agregar(new ExpedienteLaboratorio(2, "Muestra recuperada en desierto", "Dr.Rios", new Ubicacion("Chile", "Atacama"), 12, ClasificacionMuestra.TECNOLOGICA));
            archivo.agregar(new ExpedienteCampo(3, "Contacto en base austral", "Dra.Silva", new Ubicacion("Argentina", "Tierra del Fuego"), 5, TipoEvento.CONTACTO));
            archivo.agregar(new ExpedienteLaboratorio(4, "Analisis de aleacion desconocida", "Dra.Vega", new Ubicacion("Peru", "Nazca"), 8, ClasificacionMuestra.DESCONOCIDA));
            archivo.agregar(new ExpedienteCampo(5, "Abduccion en zona rural", "Dr.Molina", new Ubicacion("Uruguay", "Interior"), 5, TipoEvento.ABDUCCION));
            archivo.agregar(new ExpedienteLaboratorio(6, "Lectura de energia no terrestre", "Dr.Castro", new Ubicacion("Argentina", "Patagonia"), 15, ClasificacionMuestra.ENERGETICA));
            System.out.println("REGISTROS CARGADOS:");
            archivo.paraCadaElemento( e -> System.out.println(e) );
            System.out.println("\nREGISTROS UBICADOS EN ARGENTINA:");
            archivo.filtrar( e-> e.getUbicacion().getPais().equals("Argentina") ).forEach(e -> System.out.println(e));
            System.out.println("\nREGISTROS CUYA ZONA CONTIENE 'PATAGONIA':");
            archivo.filtrar(e-> e.getUbicacion().getZona().equals("Patagona")).forEach(e -> System.out.println(e));
            System.out.println("\nREGISTROS INVESTIGADOS POR DRA. VEGA:");
            archivo.filtrar(e->e.getInvestigador().equals("Dra.Vega")).forEach(e -> System.out.println(e));
            System.out.println("\nEXPEDIENTES DE CAMPO:");
            archivo.filtrar(e-> e instanceof ExpedienteCampo).forEach(e -> System.out.println(e));
            System.out.println("\nEXPEDIENTES DE LABORATORIO:");
            archivo.filtrar(e-> e instanceof ExpedienteLaboratorio).forEach(e -> System.out.println(e));
            System.out.println("\nREGISTROS ORDENADOS POR ID:");
            archivo.ordenar();
            archivo.paraCadaElemento(e -> System.out.println(e));
            System.out.println("\nREGISTROS ORDENADOS POR TITULO:");
            archivo.ordenar( (e1,e2) -> e1.getTitulo().compareTo(e2.getTitulo()));
            archivo.paraCadaElemento(e -> System.out.println(e));
            System.out.println("\nREGISTROS ORDENADOS POR PAIS:");
            archivo.ordenar( (e1,e2) -> (e1.getUbicacion().getPais()).compareTo(e2.getUbicacion().getPais()));
            archivo.paraCadaElemento(e -> System.out.println(e));
            System.out.println("\nREGISTROS ORDENADOS POR INVESTIGADOR Y ZONA:");
            archivo.ordenar( Comparator.comparing(RegistroAlienigena::getInvestigador).thenComparing(e -> e.getUbicacion().getZona()));
            archivo.paraCadaElemento( e-> System.out.println(e) );
            archivo.guardarEnArchivo(AppConfig.ARCHIVO_BINARIO);
            ArchivoAlienigena<RegistroAlienigena> archivoCargadoBinario = new ArchivoAlienigena<>();
            archivoCargadoBinario.cargarDesdeArchivo(AppConfig.ARCHIVO_BINARIO);
            System.out.println("\nREGISTROS CARGADOS DESDE ARCHIVO BINARIO:");
            archivoCargadoBinario.paraCadaElemento( e-> System.out.println(e) );
            archivo.guardarEnCSV(AppConfig.ARCHIVO_CSV, RegistroAlienigena.getCSVHeader());
            ArchivoAlienigena<RegistroAlienigena> archivoCargadoCSV = new ArchivoAlienigena<>();
            archivoCargadoCSV.cargarDesdeCSV(AppConfig.ARCHIVO_CSV, RegistroAlienigena::fromCSV);
            System.out.println("\nREGISTROS CARGADOS DESDE ARCHIVO CSV:");
            archivoCargadoCSV.paraCadaElemento( e-> System.out.println(e) );
            archivo.exportarTXT(AppConfig.ARCHIVO_TXT, AppConfig.TITULO_REPORTE);
            System.out.println("\nMOSTRAR REGISTROS USANDO SERVICIO:");
            List<? extends RegistroAlienigena> registrosParaMostrar = archivo.obtenerTodos();
            ServicioRegistros.mostrarRegistros(registrosParaMostrar);
            System.out.println("\nCARGAR REGISTROS DE PRUEBA USANDO SERVICIO:");
            List<RegistroAlienigena> registrosDemo = new ArrayList<>();
            ServicioRegistros.cargarRegistrosDePrueba(registrosDemo);
            for (RegistroAlienigena registro : registrosDemo) {
                archivo.agregar(registro);
            }
            System.out.println("\nREGISTROS LUEGO DE AGREGAR LOS DE PRUEBA:");
            archivo.paraCadaElemento( e-> System.out.println(e) );
            List<? super RegistroAlienigena> destinoGenerico = new ArrayList<Object>();
            ServicioRegistros.cargarRegistrosDePrueba(destinoGenerico);
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error de archivo: " + e.getMessage());
        }

    }

}
