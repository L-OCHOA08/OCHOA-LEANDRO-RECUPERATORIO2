/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 *
 * @author leand
 */
public interface Inventariable<T> {

    void agregar(T elemento);

    T obtener(int indice);

    void eliminar(int indice);

    List<T> filtrar(Predicate<? super T> criterio);

    void paraCadaElemento(Consumer<? super T> accion);

    void ordenar();

    void ordenar(Comparator<? super T> comparador);

    List<T> obtenerTodos();

}
