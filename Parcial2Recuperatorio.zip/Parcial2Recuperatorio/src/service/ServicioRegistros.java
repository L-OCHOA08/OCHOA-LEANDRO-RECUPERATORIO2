/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.List;
import model.ClasificacionMuestra;
import model.ExpedienteCampo;
import model.ExpedienteLaboratorio;
import model.RegistroAlienigena;
import model.TipoEvento;
import model.Ubicacion;

/**
 *
 * @author leand
 */
public interface ServicioRegistros<T> {
    
    public static void mostrarRegistros(List<? extends RegistroAlienigena> registros) {
        for (RegistroAlienigena registro : registros) {
            System.out.println(registro);
        }
    }
    
    public static void cargarRegistrosDePrueba(List<? super RegistroAlienigena> destino) {
        destino.add(new ExpedienteCampo(101, "Sobrevuelo cerca de base militar", "Dr. Fermi",
                new Ubicacion("Argentina", "Cordoba"), 6, TipoEvento.SIN_CONFIRMAR));
        destino.add(new ExpedienteLaboratorio(102, "Residuo organico no clasificado", "Dra. Vega",
                new Ubicacion("Brasil", "Amazonas"), 20, ClasificacionMuestra.BIOLOGICA));
    }
    
}
