
package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import persistence.Persistible;

/**
 *
 * @author Ochoa Leandro
 */
public class ArchivoAlienigena<T extends CSVSerializable & Serializable & Comparable<? super T>> implements Inventariable<T>, Persistible<T>, Iterable<T> {

    private List<T> items;

    public ArchivoAlienigena() {
        this.items = new ArrayList<>();
    }

    @Override
    public void agregar(T elemento) {
        Objects.requireNonNull(elemento);
        items.add(elemento);
    }

    @Override
    public T obtener(int indice) {
        T toReturn = null;
        try {
            toReturn = items.get(indice);
        } catch (IndexOutOfBoundsException ex) {
            System.out.println(ex.getMessage());
        }

        return toReturn;
    }

    @Override
    public void eliminar(int indice) {
        items.remove(indice);
    }

    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> toReturn = new ArrayList<>();
        for (T e : items) {
            if (criterio.test(e)) {
                toReturn.add(e);
            }
        }

        return toReturn;
    }

    @Override
    public void paraCadaElemento(Consumer<? super T> accion) {
        items.forEach(e -> accion.accept(e));
    }

    @Override
    public void ordenar() {
        items.sort(Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<? super T> comparador) {
        items.sort(comparador);
    }

    @Override
    public List<T> obtenerTodos() {
        return copiarLista();
    }

    @Override
    public void guardarEnArchivo(String ruta) throws IOException {
        Objects.requireNonNull(ruta);

        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(ruta))) {

            serializador.writeObject(items);

            System.out.println("Lista serializada con exito");

        } catch (FileNotFoundException ex) {
            System.out.println("Problema con el archivo");
        } catch (IOException ex) {
            System.out.println("Problema al serializar la lista");
        }
    }

    @Override
    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        Objects.requireNonNull(ruta);
        List<T> toReturn = null;

        try (ObjectInputStream deserializador = new ObjectInputStream(new FileInputStream(ruta))) {

            toReturn = (List<T>) deserializador.readObject();

            items.addAll(toReturn);

            System.out.println("Lista deserializada con exito");

        } catch (ClassNotFoundException ex) {
            System.out.println("Problemas con la clase");
        } catch (IOException ex) {
            System.out.println("Problema al deserializar la lista");
        }
    }

    @Override
    public void guardarEnCSV(String ruta, String encabezado) throws IOException {
        Objects.requireNonNull(ruta);
        Objects.requireNonNull(encabezado);

        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))) {

            escritor.write(encabezado + '\n');
            for (T e : items) {
                escritor.write(e.toCSV() + '\n');
            }

            System.out.println("Lista guardada en el CSV con exito");

        } catch (IOException ex) {
            System.out.println("No se pudo guardar la lista en el csv");
        }
    }

    @Override
    public void cargarDesdeCSV(String ruta, Function<String, T> mapeador) throws IOException {
        Objects.requireNonNull(ruta);

        try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {

            lector.readLine();
            String linea;

            while ((linea = lector.readLine()) != null && !linea.isBlank()) {
                T objeto = mapeador.apply(linea);
                items.add(objeto);
            }

            System.out.println("CSV cargado correctamente");

        } catch (IndexOutOfBoundsException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println("No se pudo cargar el CSV en la lista");
        }
    }

    @Override
    public void exportarTXT(String ruta, String titulo) throws IOException {
        Objects.requireNonNull(ruta);
        Objects.requireNonNull(titulo);

        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))) {

            escritor.write(titulo + '\n');
            escritor.write("--------------------------------" + '\n');

            for (T e : items) {
                escritor.write(e.toString() + '\n');
            }

        } catch (IOException ex) {
            System.out.println("TXT no se pudo exportar");
        }
    }

    @Override
    public Iterator<T> iterator() {
        if (!items.isEmpty() && items.get(0) instanceof Comparable) {
            return iterator((Comparator<T>) Comparator.naturalOrder());
        }

        return copiarLista().iterator();
    }

    public Iterator<T> iterator(Comparator<? super T> cmp) {
        return copiaOrdenada(cmp).iterator();
    }

    private List<T> copiarLista() {
        return new ArrayList<>(items);
    }

    private List<T> copiaOrdenada(Comparator<? super T> cmp) {
        List<T> copia = copiarLista();
        copia.sort(cmp);
        return copia;
    }

}
