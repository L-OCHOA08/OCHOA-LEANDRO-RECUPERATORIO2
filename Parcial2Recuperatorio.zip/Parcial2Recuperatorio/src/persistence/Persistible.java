/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package persistence;

import java.io.IOException;
import java.util.function.Function;


/**
 *
 * @author leand
 */
public interface Persistible<T> {

    void guardarEnArchivo(String ruta) throws IOException;

    void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException;

    void guardarEnCSV(String ruta, String encabezado) throws IOException;

    void cargarDesdeCSV(String ruta, Function<String, T> mapeador) throws IOException;

    void exportarTXT(String ruta, String titulo) throws IOException;

}
