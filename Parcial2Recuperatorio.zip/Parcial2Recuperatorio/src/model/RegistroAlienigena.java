/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import java.util.Objects;
import service.CSVSerializable;

/**
 *
 * @author Ochoa Leandro
 */
public abstract class RegistroAlienigena implements Comparable<RegistroAlienigena>, Serializable, CSVSerializable {

    private static final String HEADER = "tipo,id,titulo,investigador,ubicacion";
    private static final long serialVersionUID = 1L;

    private int id;
    private String titulo;
    private String investigador;
    private Ubicacion ubicacion;

    public RegistroAlienigena(int id, String titulo, String investigador, Ubicacion ubicacion) {
        this.id = id;
        this.titulo = titulo;
        this.investigador = investigador;
        this.ubicacion = ubicacion;
    }

    public static String getCSVHeader() {
        return HEADER;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getInvestigador() {
        return investigador;
    }

    public Ubicacion getUbicacion() {
        return ubicacion;
    }

    @Override
    public abstract String toCSV();

    public static RegistroAlienigena fromCSV(String linea) {
        String[] datos = linea.split(",", -1);
        
        String tipo = datos[0].trim();
        int id = Integer.parseInt(datos[1].trim());
        String titulo = datos[2].trim();
        String investigador = datos[3].trim();
        String pais = datos[4].trim();
        String zona = datos[5].trim();
        Ubicacion ubicacion = new Ubicacion(pais, zona);
        String atributoEspecifico1 = datos[6].trim();
        String atributoEspecifico2 = datos[7].trim();

        if (tipo.equals("CAMPO")) {
            int nivelRiesgo = Integer.parseInt(atributoEspecifico1);
            TipoEvento tipoEvento = TipoEvento.valueOf(atributoEspecifico2);
            return new ExpedienteCampo(id, titulo, investigador, ubicacion, nivelRiesgo, tipoEvento);
        } else if (tipo.equals("LABORATORIO")) {
            int muestrasAnalizadas = Integer.parseInt(atributoEspecifico1);
            ClasificacionMuestra clasificacion = ClasificacionMuestra.valueOf(atributoEspecifico2);
            return new ExpedienteLaboratorio(id, titulo, investigador, ubicacion, muestrasAnalizadas, clasificacion);
        } else {
            throw new IllegalArgumentException("Tipo de registro desconocido: " + tipo);
        }

    }

    @Override
    public int compareTo(RegistroAlienigena otro) {
        return Integer.compare(this.id, otro.id);
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "{" + "id=" + id + ", titulo=" + titulo + ", investigador=" + investigador + ", ubicacion=" + ubicacion;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof RegistroAlienigena e)) {
            return false;
        }
        return id == e.id;
    }

}
