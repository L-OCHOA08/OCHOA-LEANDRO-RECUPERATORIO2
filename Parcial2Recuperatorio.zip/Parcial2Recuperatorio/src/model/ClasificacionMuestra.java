/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Ochoa Leandro
 */
public enum ClasificacionMuestra {
    BIOLOGICA, TECNOLOGICA, ENERGETICA, DESCONOCIDA
}
