
package model;

/**
 *
 * @author leand
 */
public class ExpedienteLaboratorio extends RegistroAlienigena{
    
    private static final String HEADER = RegistroAlienigena.getCSVHeader() + ",muestrasAnalizadas,clasificacion";
    private static final long serialVersionUID = 1L;
    
    private int muestrasAnalizadas;
    private ClasificacionMuestra clasificacion;

    public ExpedienteLaboratorio(int id, String titulo, String investigador, Ubicacion ubicacion, int muestrasAnalizadas, ClasificacionMuestra clasificacion) {
        super(id, titulo, investigador, ubicacion);
        this.muestrasAnalizadas = muestrasAnalizadas;
        this.clasificacion = clasificacion;
    }

    public int getMuestrasAnalizadas() {
        return muestrasAnalizadas;
    }

    public ClasificacionMuestra getClasificacion() {
        return clasificacion;
    }

    public static String getHEADER() {
        return HEADER;
    }

    @Override
    public String toCSV() {
        return String.join(",","LABORATORIO",String.valueOf(getId()),getTitulo(),getInvestigador(),getUbicacion().getPais(),getUbicacion().getZona(),String.valueOf(muestrasAnalizadas),clasificacion.name());
    }

    @Override
    public String toString() {
        return super.toString() + ", muestrasAnalizadas=" + muestrasAnalizadas + ", clasificacion=" + clasificacion + '}';
    }
    
    
    
    
}
