/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author leand
 */
public class ExpedienteCampo extends RegistroAlienigena {
    
    private static final String HEADER = RegistroAlienigena.getCSVHeader() + ",nivelRiesgo,tipoEvento";
    private static final long serialVersionUID = 1L;
    
    private int nivelRiesgo;
    private TipoEvento tipoEvento;

    public ExpedienteCampo(int id, String titulo, String investigador, Ubicacion ubicacion, int nivelRiesgo, TipoEvento tipoEvento) {
        super(id, titulo, investigador, ubicacion);
        this.nivelRiesgo = nivelRiesgo;
        this.tipoEvento = tipoEvento;
    }

    public int getNivelRiesgo() {
        return nivelRiesgo;
    }

    public TipoEvento getTipoEvento() {
        return tipoEvento;
    }

    public static String getHEADER() {
        return HEADER;
    }

    @Override
    public String toCSV() {
        return String.join(",","CAMPO",String.valueOf(getId()),getTitulo(),getInvestigador(),getUbicacion().getPais(),getUbicacion().getZona(),String.valueOf(nivelRiesgo),tipoEvento.name());
    }

    @Override
    public String toString() {
        return super.toString() + ", nivelRiesgo=" + nivelRiesgo + ", tipoEvento=" + tipoEvento + '}';
    }

    
    
    
    
}
