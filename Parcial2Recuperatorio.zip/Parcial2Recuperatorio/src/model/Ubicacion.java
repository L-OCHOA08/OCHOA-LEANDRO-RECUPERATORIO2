/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;

/**
 *
 * @author leand
 */
public class Ubicacion implements Serializable{
    
    private static final long serialVersionUID = 1L;
    
    private String pais;
    private String zona;

    public Ubicacion(String pais, String zona) {
        this.pais = pais;
        this.zona = zona;
    }

    public String getPais() {
        return pais;
    }

    public String getZona() {
        return zona;
    }

    @Override
    public String toString() {
        return "Ubicacion{" + "pais=" + pais + ", zona=" + zona + '}';
    }
    
    
    
}
