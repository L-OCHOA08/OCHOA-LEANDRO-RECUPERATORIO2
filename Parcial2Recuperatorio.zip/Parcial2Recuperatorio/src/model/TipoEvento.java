/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author leand
 */
public enum TipoEvento {
    AVISTAMIENTO, CONTACTO, ABDUCCION, ENCUBRIMIENTO, SIN_CONFIRMAR
}
